create
    definer = root@localhost function get_favorites(id int) returns varchar(140) deterministic
    RETURN (
      # Write your MySQL query statement below.
     select content from tweets where id in ( SELECT f.tweets_id from favorites 
     f left join users on users.id = f.user_id)
     );

