create
    definer = root@localhost procedure GetCustomer(IN currentDate date)
Begin
	select fis.customerkey, fis.salesamount,
	   case when DATEDIFF(currentDate, dc.birthdate) / 365.25 > 70 then 'Elder'
			when DATEDIFF(currentDate, dc.birthdate) / 365.25 <= 50 then 'Younger'
			else 'Middle Age'
       end as Age
	from aw.FactInternetSales fis left join aw.DimCustomer dc on fis.customerkey = dc.customerkey;
End;

