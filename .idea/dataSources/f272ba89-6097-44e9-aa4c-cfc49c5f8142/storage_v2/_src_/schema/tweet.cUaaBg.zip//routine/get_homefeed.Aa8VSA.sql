create
    definer = root@localhost function get_homefeed(i int) returns varchar(140) deterministic
    RETURN (
      # Write your MySQL query statement below.
     Select content from tweets where i in (
     select user_id from follow f left join users on users.id = f.user_id  ) order by post_time desc
     );

