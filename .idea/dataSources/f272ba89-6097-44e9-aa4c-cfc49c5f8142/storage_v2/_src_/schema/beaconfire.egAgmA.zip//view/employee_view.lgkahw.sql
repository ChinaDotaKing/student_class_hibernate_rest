create definer = root@localhost view employee_view as
select `beaconfire`.`employees`.`id`        AS `id`,
       `beaconfire`.`employees`.`firstname` AS `firstname`,
       `beaconfire`.`employees`.`lastname`  AS `lastname`,
       `beaconfire`.`employees`.`username`  AS `username`
from `beaconfire`.`employees`;

