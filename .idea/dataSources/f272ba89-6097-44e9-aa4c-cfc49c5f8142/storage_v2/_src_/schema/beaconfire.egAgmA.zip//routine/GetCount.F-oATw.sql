create
    definer = root@localhost procedure GetCount(IN categoryName varchar(50), OUT count1 int)
Begin
	select count(*) INTO count1 from beaconfire.products where category = categoryName;
End;

