create
    definer = root@localhost function full_name(firstname char(50), lastname char(50)) returns char(100) deterministic
    RETURN CONCAT(firstname,' ', lastname);

